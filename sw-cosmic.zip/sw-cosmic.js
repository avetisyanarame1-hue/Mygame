// Flyball — Cosmic Worlds offline cache
// Versioned cache so installed copies refresh after the cosmic redesign.

const CACHE_NAME = 'flyball-cosmic-v2';
const CORE_ASSETS = [
  './',
  './index.html',
  './manifest.json'
];
const OPTIONAL_ASSETS = [
  './icon-192.png',
  './icon-512.png'
];

self.addEventListener('install', function (event) {
  event.waitUntil((async function () {
    const cache = await caches.open(CACHE_NAME);
    // Core files must be available for the install to succeed.
    await cache.addAll(CORE_ASSETS);
    // Icons are optional: a missing icon must not prevent the game installing.
    await Promise.all(OPTIONAL_ASSETS.map(function (asset) {
      return cache.add(asset).catch(function () {});
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', function (event) {
  event.waitUntil((async function () {
    const names = await caches.keys();
    await Promise.all(names
      .filter(function (name) { return name.startsWith('flyball-') && name !== CACHE_NAME; })
      .map(function (name) { return caches.delete(name); }));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', function (event) {
  if (event.request.method !== 'GET') return;
  const requestURL = new URL(event.request.url);
  if (requestURL.origin !== self.location.origin) return;

  event.respondWith((async function () {
    const cached = await caches.match(event.request);
    if (cached) return cached;

    try {
      const response = await fetch(event.request);
      if (response && response.ok) {
        const cache = await caches.open(CACHE_NAME);
        cache.put(event.request, response.clone()).catch(function () {});
      }
      return response;
    } catch (error) {
      const fallback = await caches.match('./index.html');
      if (fallback) return fallback;
      throw error;
    }
  })());
});
